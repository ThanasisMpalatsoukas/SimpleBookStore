<div class="book-container">
    <div class="book image" style="background-image:url( {{ asset( $image )}} )">
        <div class="buy-option">
            <div class="cart-icon image" style="background-image:url( {{ asset('storage/cart.png') }} )">
                <div class="red-circle">
                    <p>+</p>
                </div>
            </div>
        </div>
    </div>
</div>