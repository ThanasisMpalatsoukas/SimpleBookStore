<nav class="book-categories">
    <div class="container">
        <ul id="menu-items">
            <?php $__currentLoopData = App\Category::all()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li id="<?php echo e($category['id']); ?>"><p><?php echo e($category['name']); ?></p><div class="image menu-icon" style="background-image:url( <?php echo e(asset('storage/'.$category['category_cover'])); ?> );"></div></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/layout/menu.blade.php ENDPATH**/ ?>