<?php if( isset( $_GET['warning'] ) ): ?>
    <div class="warning">
        <input type="hidden" id="warning-exists" value="<?php echo $_GET['warning']; ?>">
        <?php if( $_GET['warning'] == 1 ): ?>
            <p>You need to be logged in to finish this action</p>
        <?php endif; ?>
        <?php if( $_GET['warning'] == 2 ): ?>
            <p>There is nothing in the cart</p>
        <?php endif; ?>
    </div>
<?php elseif(  isset( $warning ) ): ?>
    <div class="warning">
        <input type="hidden" id="warning-exists" value="<?php echo $warning; ?>">
        <?php if( $warning == 1 ): ?>
            <p>You need to be logged in to finish this action</p>
        <?php endif; ?>
        <?php if( $warning == 2 ): ?>
            <p>There is nothing in the cart</p>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/layout/warning.blade.php ENDPATH**/ ?>