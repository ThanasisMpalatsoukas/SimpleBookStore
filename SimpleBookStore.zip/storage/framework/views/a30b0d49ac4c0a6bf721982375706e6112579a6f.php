<div class="category-items" id="category-items">
    <div class="container" id="category-items-container">

        <?php if( $category == '' ||  !in_array( $category , App\Category::getBookCategoryNames() ) ): ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(  $book['category_id'] ==  App\Category::getBookIds()[0]  ): ?>
                    <div class="book-container">
                        <a href="/item/<?php echo e($book['id']); ?>">
                            <div class="book image" style="background-image:url( <?php echo e(asset( 'storage/'.$book['book_image'] )); ?> )">
                                <div class="buy-option">
                                    <div class="cart-icon image" style="background-image:url( <?php echo e(asset('storage/cart.png')); ?> )">
                                        <div class="red-circle">
                                            <p>+</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(  $book->category->name == $category ): ?>
                    <div class="book-container">
                        <a href="/item/<?php echo e($book['id']); ?>">
                            <div class="book image" style="background-image:url( <?php echo e(asset( 'storage/'.$book['book_image'] )); ?> )">
                                <div class="buy-option">
                                    <div class="cart-icon image" style="background-image:url( <?php echo e(asset('storage/cart.png')); ?> )">
                                        <div class="red-circle">
                                            <p>+</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <div class="button-container">
            <button id="load-more-items">See more</button>
        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/layout/categoryItems.blade.php ENDPATH**/ ?>