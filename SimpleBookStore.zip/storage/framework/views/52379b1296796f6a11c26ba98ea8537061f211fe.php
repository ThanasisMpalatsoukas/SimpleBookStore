            <footer>
                <div class="container">
                    <div class="footer-space">
                        <p>Phone : +30 6988711872</p>
                        <p>Email : Thanasismpalatsoukas@gmail.com</p>
                        <p>Adress : Kotroni trikalwn , trikala</p>
                    </div>
                    <div class="footer-space">
                        <p>Phone : +30 6988711872</p>
                        <p>Email : Thanasismpalatsoukas@gmail.com</p>
                        <p>Adress : Kotroni trikalwn , trikala</p>
                    </div>
                    <div class="footer-space">
                        <p>Phone : +30 6988711872</p>
                        <p>Email : Thanasismpalatsoukas@gmail.com</p>
                        <p>Adress : Kotroni trikalwn , trikala</p>
                    </div>
                </div>
            </footer>

            <div class="credentials">
                <p>Website designed and developed by Thanasis Mpalatsoukas</p>
            </div>

        </main>
</body>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
    <script type="module" src="<?php echo e(asset('js/index.js')); ?>"></script>
</html>
</body><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/layout/footer.blade.php ENDPATH**/ ?>