<?php echo $__env->make('home.layout.header', ['headerClass' => 'index-header'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- invisible log-in table -->
<?php if( !Auth::check() ): ?>
    <?php echo $__env->make('home.layout.nonAuthorizedUsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
<?php endif; ?>
<script
    src="https://www.paypal.com/sdk/js?client-id=<?php echo e(env('PAYPAL_CLIENT_ID')); ?>">
</script>
<div class="breadcrumps">
    <p><a href="../../">home</a> > <a href="../../books/-1">books</a> > purchase</p>
</div>

<main style="margin-top:-20px;background-color:#f9f9f9;">
    <div class="container purchase">
        <h1>Cart</h1>
        <div class="billing-information">
            <table>
                <tr>
                    <th colspan='2'>Billing information</th>
                </tr>
                <tr>
                    <td>Name:</td>
                    <td><?php echo e(Auth::user()->name); ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?php echo e(Auth::user()->email); ?></td>
                </tr>
                <tr>
                    <td>Phone number:</td>
                    <td><?php echo e(Auth::user()->phone); ?></td>
                </tr>
                <tr>
                    <td>City:</td>
                    <td><?php echo e(App\City::find(Auth::user()->city)->name); ?></td>
                </tr>
                <tr>
                    <td>region:</td>
                    <td><?php echo e(App\Region::find(Auth::user()->region)->name); ?></td>
                </tr>
                <tr>
                    <td>address:</td>
                    <td><?php echo e(Auth::user()->address); ?></td>
                </tr>
                <tr>
                    <td>Comments:</td>
                    <td><textarea name="comments" id="comments" style="width:100%;height:100px;"></textarea></td>
                </tr>
            </table>
            <div class="total-payout">
                <p style="text-align: center;">The total cost is : <span id="total-amount-of-money"><?php echo e(App\Cart::getTotalPayment( $books , $amount_of_books )); ?></span>$</p><br>
                <div id="paypal-button-container"></div>
            </div>
        </div>
        <div class="item">
        <?php if(!empty( $books )): ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-book" id="b<?php echo e($book['id']); ?>">
                    <div class="book-cover image" style="background-image:url( <?php echo e(asset('storage/'.$book['book_image'])); ?> );">

                    </div>
                    <table>
                        <tr>
                            <td style="font-size:12px;font-weight:700;padding:10px;"><?php echo e($book['title']); ?></td>
                        </tr>
                        <tr>
                            <td style="padding-top: 5px;padding-left:10px;"><?php echo e($authors[$i]); ?></td>
                        </tr>
                        <tr>
                            <td class="amount-of-books" data-amount="<?php echo e($amount_of_books[$i]); ?>" style="padding-top: 5px;padding-left:10px;" id="times<?php echo e($book['id']); ?>"><?php echo e($amount_of_books[$i]); ?> X <?php echo e(App\Book::getTotalPrice( $book )); ?>$</td>
                        </tr>
                    </table>
                    <div class="remove-item image" data-id="<?php echo e($book['id']); ?>" style="background-image:url( <?php echo e(asset('storage/exit-icon-black.png')); ?> );">
    
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php endif; ?>
        </div>
    </div>
</main>
<?php echo $__env->make('home.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    const totalCost = document.getElementById('total-amount-of-money').innerHTML;

    paypal.Buttons({
    createOrder: function(data, actions) {
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: totalCost
          }
        }]
      });
    },
    onApprove: function(data, actions) {
      return actions.order.capture().then(function(details) {
        alert('Transaction completed by ' + details.payer.name.given_name);
        // Call your server to save the transaction

        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        let amount_of_books = [];
        $('.amount-of-books').each(function(obj){
            amount_of_books.push( $(this).data('amount') );
        });

        let comments = $('#comments').val();
        if (comments == '') {
            comments = '-';
        }

        $.ajax({

            type:'GET',
            url:'/paypal-transaction-complete',
            data: { amount_of_books : amount_of_books , 'comments' : comments },
            dataType:'html',

            success: function(respose){
                // response == 0 means the cart number will be lowered
                window.location.replace('/books/-1?purchase=completed');
            }

        });

      });
    }
  }).render('#paypal-button-container');
</script>             <?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/purchase/index.blade.php ENDPATH**/ ?>