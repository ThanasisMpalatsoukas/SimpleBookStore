<?php echo $__env->make('home.layout.header',['headerClass' => 'single-item-header'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if( !Auth::check() ): ?>
    <?php echo $__env->make('home.layout.nonAuthorizedUsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
    <div class="breadcrumps">
        <p><a href="../../">home</a> > <a href="../../books/-1">books</a> > <a href="../../item/<?php echo e($book['id']); ?>"><?php echo e($book['title']); ?> </a>> review</p>
    </div>

    <input type="hidden" id="book_id" name="book_id" value="<?php echo e($book['id']); ?>">
    <main class="reviews" id="reviews">

    </main>


    <!-- Include footer -->
    <footer>
            <div class="container">
                <div class="footer-space">
                    <p>Phone : +30 6988711872</p>
                    <p>Email : Thanasismpalatsoukas@gmail.com</p>
                    <p>Adress : Kotroni trikalwn , trikala</p>
                </div>
                <div class="footer-space">
                    <p>Phone : +30 6988711872</p>
                    <p>Email : Thanasismpalatsoukas@gmail.com</p>
                    <p>Adress : Kotroni trikalwn , trikala</p>
                </div>
                <div class="footer-space">
                    <p>Phone : +30 6988711872</p>
                    <p>Email : Thanasismpalatsoukas@gmail.com</p>
                    <p>Adress : Kotroni trikalwn , trikala</p>
                </div>
            </div>
        </footer>

        <div class="credentials">
            <p>Website designed and developed by Thanasis Mpalatsoukas</p>
        </div>
        <script src="<?php echo e(asset('js/review.js')); ?>"></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/reviews.blade.php ENDPATH**/ ?>