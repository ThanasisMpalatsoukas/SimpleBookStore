<?php echo $__env->make('home.layout.header',['headerClass' => 'index-header'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if( !Auth::check() ): ?>
            <?php echo $__env->make('home.layout.nonAuthorizedUsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <div class="breadcrumps">
            <p><a href="../../">home</a> > books</p>
        </div>
        <input type="hidden" id="category_id" name="category_id" value="<?php echo e($category); ?>">

        <!-- React js app here -->
        <main class="items-by-category" id="products-by-filter">
  
        </main>

        <!-- Footer area -->
        <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/productsByFilter.blade.php ENDPATH**/ ?>