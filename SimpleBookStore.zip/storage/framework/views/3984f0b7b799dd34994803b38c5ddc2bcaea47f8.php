<div class="login-black-container" id="login-black-container" style="<?php echo e(isset($_GET['warning']) ? 'opacity:1;display:block;height:100vh;width:100vw;display:flex;' : ''); ?>" >
    <div class="login-card">
        <div class="exit-icon image" id="exit-icon" style="background-image:url( <?php echo e(asset('storage/exit-icon-black.png')); ?> )">

        </div>
        <div class="login">
            <table>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <tr>
                        <th colspan='2'>LOGIN</th>
                    </tr>
                    <tr>
                        <td>EMAIL :</td>
                        <td><input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus></td>
                    </tr>
                    <tr>
                        <td>PASSWORD :</td>
                        <td><input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password"></td>
                    </tr>
                    <tr>
                        <td colspan='2'><button type="submit"><?php echo e(__('Login')); ?></button></td>
                    </tr>
                </form>
            </table>
        </div>
        <div class="register">
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>
                <table>
                    <tr>
                        <th colspan='2'>REGISTER</th>
                    </tr>
                    <tr>
                        <td>USERNAME</td>
                        <td><input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus></td>
                    </tr>
                    <tr>
                        <td>EMAIL</td>
                        <td><input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"></td>
                    </tr>
                    <tr>
                        <td>CITY</td>
                        <td>
                            <select name="city" id="city">
                                <?php $__currentLoopData = App\City::all()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city['id']); ?>"><?php echo e($city['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>REGION</td>
                        <td>
                            <select name="region" id="region">
                                <?php $__currentLoopData = App\Region::all()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($region['id']); ?>"><?php echo e($region['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>ADDRESS</td>
                        <td><input id="address" type="text" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address" required autocomplete="new-password"></td>
                    </tr>
                    <tr>
                        <td>PHONE NUMBER</td>
                        <td><input id="phone" type="text" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" required autocomplete="new-password"></td>
                    </tr>
                    <tr>
                        <td>PASSWORD</td>
                        <td><input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password"></td>
                    </tr>
                    <tr>
                        <td>CONFIRM PASSWORD</td>
                        <td><input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password"></td>
                    </tr>
                    <tr>
                        <td colspan='2'><button>Submit</button></td>
                    </tr>
                    <tr>
                        <td style="padding-top:30px;font-size: 14px;" colspan='2'>*By registering you confirm that we can use your<br>information on our system to give you the best experience</td>
                    </tr>
                    <input type="hidden" id="number_of_cities" value="<?php echo e(App\City::all()->count()); ?>">
                </table>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/home/layout/nonAuthorizedUsers.blade.php ENDPATH**/ ?>