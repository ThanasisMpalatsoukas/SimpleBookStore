        <?php echo $__env->make('home.layout.header',['headerClass' => 'single-item-header'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if( !Auth::check() ): ?>
            <?php echo $__env->make('home.layout.nonAuthorizedUsers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <div class="breadcrumps">
            <p><a href="../../">home</a> > <a href="../../books/-1">books</a> > <?php echo e($book['title']); ?></p>
        </div>
        <div class="confirm-purchase" id="confirm-purchase">
            <p>Your item has been added to the cart</p>
        </div>
        <div id="warning-container">

        </div>
        <main class="single-item">
            <div class="navbar-container">
                <nav>
                    <ul>
                        <?php $__currentLoopData = App\Category::all()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="../../books/<?php echo e($item['id']); ?>"><?php echo e($item['name']); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </nav>
            </div>
            <div class="content-container">
                <div class="book-info">
                    <div class="change-book" style="float:left;">
                        <?php if( $book['id'] - 1 > 0 ): ?>
                        <a href="<?php echo e($book['id'] - 1); ?>">
                            <div class="image" style="background-image:url(<?php echo e(asset('storage/triangle-left.png')); ?>)"></div>  
                        </a>
                        <?php endif; ?>
                    </div>
                    <table>
                        <tr>
                            <th colspan='2'><?php echo e($book['title']); ?></th>
                        </tr>
                        <tr>
                            <td>ISBN</td>
                            <td><?php echo e($book['ISBN']); ?></td>
                        </tr>
                        <tr>
                            <td>Year of publication</td>
                            <td><?php echo e($book['yearOfPublication']); ?></td>
                        </tr>
                        <tr>
                            <td>Pages</td>
                            <td><?php echo e($book['pages']); ?></td>
                        </tr>
                        <tr>
                            <td>Category</td>
                            <td><a href="../../books/<?php echo e($category['id']); ?>"><?php echo e($category['name']); ?></a></td>
                        </tr>
                        <tr>
                            <td>Author</td>
                            <td><?php echo e($author); ?></td>
                        </tr>
                        <tr>
                            <td>Books available</td>
                            <td><?php echo e($book['amount_available']); ?></td>
                        </tr>
                        <tr>
                            <td colspan='2' class="description" style="font-weight:400;"><?php echo e($book['description']); ?></td>
                        </tr>
                        <tr>
                            <?php if( $book['discount'] == 0 ): ?>
                            <td colspan='2' class="price">
                                <?php echo e($book['price'] + App\Region::getCostByRegion()); ?>$
                                <?php if( Auth::check() ): ?>
                                    <span class="transportation-cost">( Transportation cost is included ( <?php echo e(App\Region::getCostByRegion()); ?>$ ) )</span>
                                <?php else: ?>
                                    <span class="transportation-cost">( Transportation cost is not included )</span>
                                <?php endif; ?>
                            </td>
                            <?php else: ?>
                            <td colspan='2' class="price">
                                <span class="endprice"><?php echo e(App\Book::getTotalPrice( $book )); ?>$</span>
                                <span class="strikethrough"><?php echo e($book['price'] + App\Region::getCostByRegion()); ?>$ ( save <?php echo e($book['discount']); ?>% )</span>
                                <?php if( Auth::check() ): ?>
                                    <span class="transportation-cost">( Transportation cost is included ( <?php echo e(App\Region::getCostByRegion()); ?>$ ) )</span>
                                <?php else: ?>
                                    <span class="transportation-cost">( Transportation cost is not included )</span>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <td colspan='2' style="opacity:1;">
                                <button id="add-single-book-item">Add item</button>
                                <input type="hidden" id="book_id" name="book_id" value="<?php echo e($book['id']); ?>">
                            </td>
                        </tr>
                    </table>
                    <div class="book-cover-container image" style="background-image:url( <?php echo e(asset('storage/'.$book['book_image'] )); ?> );background-size:contain;background-repeat:no-repeat;">

                    </div>
                    <div class="book-review">
                        <a class="review-item" href="#write-review">Review this product</a>
                        <div class="stars image" id="start" data-amount="<?php echo e($review_mean); ?>" style="background-image:url( <?php echo e(asset('storage/stars.png' )); ?> );">
                            <p>( <?php echo e($review_mean); ?> )</p>
                            <p><a href="../../reviews/<?php echo e($book['id']); ?>">( read reviews )</a></p>
                        </div>
                        <div class="stars-overlay" style="width:<?php echo e($review_mean*30); ?>px;">
                        </div>
                        
                    </div>
                    <div class="change-book" style="float:right">
                    <?php if( $book['id'] + 1 < count(App\Book::all()) ): ?>
                    <a href="<?php echo e($book['id']+1); ?>">
                      <div class="image" style="background-image:url(<?php echo e(asset('storage/triangle-right.png')); ?>)"></div>  
                    </a>
                    <?php endif; ?>
                </div>
                </div>
                <div class="details">
                    <h3>Details</h3>
                    <p><?php echo e($book['details']); ?></p>
                </div>
                <?php if( $review_enabled ): ?>
                <div class="write-review-container" id="write-review">
                    <div class="write-review">
                        <div id="review-response">

                        </div>
                        <p>Your rating <sup>(*)</sup></p>
                        <div class="star-container">
                            <div class="single-star image" data-num="0" style="background-image:url(<?php echo e(asset('storage/single-transparent-star.png')); ?>);">
                            </div>
                            <div class="single-star image" data-num="1" style="background-image:url(<?php echo e(asset('storage/single-transparent-star.png')); ?>);">
                            </div>
                            <div class="single-star image" data-num="2" style="background-image:url(<?php echo e(asset('storage/single-transparent-star.png')); ?>);">
                            </div>
                            <div class="single-star image" data-num="3" style="background-image:url(<?php echo e(asset('storage/single-transparent-star.png')); ?>);">
                            </div>
                            <div class="single-star image" data-num="4" style="background-image:url(<?php echo e(asset('storage/single-transparent-star.png')); ?>);">
                            </div>
                            <div class="color-override">
                            </div>
                            <div class="yellow-color-override" id="yellow-color-override">
                            </div>
                            <input type="hidden" name="stars" id="previous-star-count" data-num="<?php echo e($stars); ?>">
                        </div>
                        <p style="margin-top:30px;">Write your comment</p>
                        <textarea cols="60" rows="30" name="review-comment" id="review-comment" value="<?php echo e($comment); ?>"><?php echo e($comment); ?></textarea>
                        <br>
                        <button id="send-review">Send review</button>
                    </div>
                </div>
                <?php else: ?>
                <div class="container">
                    <div class="warning-review">
                        <p>To write a review you need to be logged in</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>            
        </main>
        <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
        <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\SimpleBookStore\resources\views/singleItem/singleItem.blade.php ENDPATH**/ ?>